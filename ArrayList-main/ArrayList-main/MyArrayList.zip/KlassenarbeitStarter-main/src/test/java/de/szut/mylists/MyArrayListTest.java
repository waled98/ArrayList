package de.szut.mylists;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;

public class MyArrayListTest {

    @Test
    void testSizeInitiallyZero() {
        MyArrayList list = new MyArrayList();
        assertThat(list.size()).isZero();
    }

    @Test
    void testAddIncreasesSize() {
        MyArrayList list = new MyArrayList();
        list.add(5);
        assertThat(list.size()).isEqualTo(1);
    }

    @Test
    void testGetReturnsCorrectValue() {
        MyArrayList list = new MyArrayList();
        list.add(10);
        list.add(20);
        assertThat(list.get(0)).isEqualTo(10);
        assertThat(list.get(1)).isEqualTo(20);
    }

    @Test
    void testGetThrowsExceptionForInvalidIndex() {
        MyArrayList list = new MyArrayList();
        assertThatThrownBy(() -> list.get(0)).isInstanceOf(RuntimeException.class).hasMessage("Dieser Index existiert nicht!");
    }

    @Test
    void testRemoveDecreasesSizeAndShiftsElements() {
        MyArrayList list = new MyArrayList();
        list.add(5);
        list.add(10);
        list.add(15);
        list.remove(1);
        assertThat(list.size()).isEqualTo(2);
        assertThat(list.get(1)).isEqualTo(15);
    }

    @Test
    void testRemoveThrowsExceptionForInvalidIndex() {
        MyArrayList list = new MyArrayList();
        assertThatThrownBy(() -> list.remove(0)).isInstanceOf(RuntimeException.class).hasMessage("Dieser Index existiert nicht!");
    }

    @Test
    void testContainsReturnsTrueIfValueExists() {
        MyArrayList list = new MyArrayList();
        list.add(5);
        assertThat(list.contains(5)).isTrue();
    }

    @Test
    void testContainsReturnsFalseIfValueDoesNotExist() {
        MyArrayList list = new MyArrayList();
        list.add(5);
        assertThat(list.contains(10)).isFalse();
    }
}
