package de.szut.mylists;
import java.util.Arrays;
public class MyArrayList {
    private int[] elements;
    private int size;
    public MyArrayList() {
        elements = new int[10];
        size = 0;
    }
    public int size() {
        return size;
    }
    public void add(int value) {
        ensureCapacity();
        elements[size++] = value;
    }
    public int get(int index) {
        checkIndex(index);
        return elements[index];
    }
    public void remove(int index) {
        checkIndex(index);
        for (int i = index; i < size - 1; i++) {
            elements[i] = elements[i + 1];
        }
        size--;
    }
    public boolean contains(int value) {
        for (int i = 0; i < size; i++) {
            if (elements[i] == value) {
                return true;
            }
        }
        return false;
    }
    private void ensureCapacity() {
        if (size == elements.length) {
            elements = Arrays.copyOf(elements, elements.length + 10);
        }
    }
    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new RuntimeException("Dieser Index existiert nicht!");
        }
    }
}
